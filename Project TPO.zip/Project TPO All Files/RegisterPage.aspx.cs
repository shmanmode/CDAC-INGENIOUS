﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



    protected void Unnamed1_Click(object sender, EventArgs e)
    {
        if( lblmobileno.Text == "" || txt_email.Text == "")
        {

            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Fields are required');", true);


         //   Response.Write("<script> alert('fields are required')</script>");

        }
        else
        {
            try
            {

                Session["emailid"] = txt_email.Text;
                Session["mobileno"] = lblmobileno.Text;

                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = CommandType.StoredProcedure;
                cmdInsert.CommandText = "RegistrationProcedure";

                cmdInsert.Parameters.AddWithValue("@StudentId", Request["sid"]);
                cmdInsert.Parameters.AddWithValue("@FirstName", Request["firstname"]);
                cmdInsert.Parameters.AddWithValue("@MiddleName", Request["middlename"]);
                cmdInsert.Parameters.AddWithValue("@LastName", Request["lastname"]);
                cmdInsert.Parameters.AddWithValue("@MobileNo", lblmobileno.Text);
                cmdInsert.Parameters.AddWithValue("@Email", txt_email.Text);

                cmdInsert.Parameters.AddWithValue("@ConfirmPassword", TextBox2.Text);

                cn.Open();
                cmdInsert.ExecuteNonQuery();
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Redirect("RegisterPage.aspx");
              
            }


        }
        
   

        // ---------SMTP and SMS   ----------------------------------------------------------------

        //SMS Sending------------------------------------------------------
        String Mobile = "9757374616";
        String Password = "Shivam@97";
        String Message = "Hello \n" + Request["firstname"] + " " + Request["lastname"] + " You have registered successfully to CDAC-INGENIOUS ";
        String No = lblmobileno.Text;
        String Key = "panwaTcrCPf0GvZ8Uhgikj7xbo";
        String URL = "https://smsapi.engineeringtgr.com/send/?Mobile=" + Mobile + "&Password=" + Password + "&Key=" + Key + "&Message=" + Message + "&To=" + No + "";

        ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls | SecurityProtocolType.Ssl3;
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
        request.Method = "GET";
        request.ContentType = "application/json";
        request.ContentLength = 0;
        try
        {
            //SMTP MAIL----------------------------------------------------------------------------------------------
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential("cdac.ingenious@gmail.com", "Password888");
            MailMessage msgobj = new MailMessage();
            msgobj.To.Add(txt_email.Text);
            msgobj.From = new MailAddress("cdac.ingenious@gmail.com");
            msgobj.Subject = "CDAC-IGNENIOUS";
            msgobj.Body = "Hello \n" + Request["firstname"]+ " " + Request["lastname"] + " You have registered successfully to CDAC-INGENIOUS ";
            client.Send(msgobj);
            //Response.Write("Mail send successfully");

            //SMS----------------------------------------------------------------------------------------------------
            HttpWebResponse webResponse = (HttpWebResponse)request.GetResponse();
            Stream webStream = webResponse.GetResponseStream();
            StreamReader responseReader = new StreamReader(webStream);
            String response = responseReader.ReadToEnd();
            Console.Out.WriteLine(response);
            responseReader.Close();
           // ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert('Registered  successfully');", true);
        }

        catch (Exception ex)
        {
            Response.Write("Registration Failed" + ex.Message);
        }


        //-----------------------------------------------------------------------------------------
       
        Response.Redirect("LoginPage.aspx");
    }

    
}
