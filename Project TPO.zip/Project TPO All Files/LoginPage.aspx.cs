﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LoginPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button4_Click(object sender, EventArgs e)
    {

    }

    protected void Button2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("RegisterPage.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("RegisterPage.aspx");
    }

    protected void Button4_Click1(object sender, EventArgs e)
    {
        Response.Redirect("RegisterPage.aspx");
    }

    protected void studloginbtn_Click(object sender, EventArgs e)
    {
       

        string username = Request["UserId"];
        string password = Request["password"];
        if (CheckUser(username, password))
        {
            Session["stdid"] = Request["UserId"];
            Session["confirmpassword"] = Request["password"];
            Response.Redirect("StudentHomePage.aspx");
        }
        else
        {
            Response.Redirect("LoginPage.aspx");
        }

    }
    private bool CheckUser(string username, string password)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.CommandType = CommandType.Text;
        cm.CommandText = "select count(*) from Registration where StudentId=@StudId and ConfirmPassword=@password";
        cm.Parameters.AddWithValue("@StudId", username);
        cm.Parameters.AddWithValue("@password", password);
        cn.Open();
        int result = (int)cm.ExecuteScalar();
        cn.Close();
        if (result == 1)
            return true;
        else
            return false;
    }



    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        int intId = 100;

        string strPopup = "<script language='javascript' ID='script1'>"

        // Passing intId to popup window.
        + "window.open('ForgetPassword.aspx?data=" + HttpUtility.UrlEncode(intId.ToString())

        + "','new window', 'top=90, left=200, width=300, height=100, dependant=no, location=0, alwaysRaised=no, menubar=no, resizeable=no, scrollbars=n, toolbar=no, status=no, center=yes')"

        + "</script>";

        ScriptManager.RegisterStartupScript((Page)HttpContext.Current.Handler, typeof(Page), "Script1", strPopup, false);
    }
}