﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
        }
            Console.WriteLine("hello");

            SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand cmdFetch = new SqlCommand();
            cmdFetch.Connection = cn;
            cmdFetch.CommandType = CommandType.Text;


        cmdFetch.CommandText = " SELECT  Basic_Info_Master.StudentId ,  Basic_Info_Master.FullName , Basic_Info_Master.EmailId , Basic_Info_Master.MobileNo , Basic_Info_Master.Address , Basic_Info_Master.PinCode , Basic_Info_Master.City , Basic_Info_Master.State , Basic_Info_Master.Country," +
            "Academics_Master_CCEE.CCEEMarks , Academics_Master_CCEE.Percentage , Academics_Master_CCEE.WorkExperience ," +
            "Academics_Master10.SchoolName , Academics_Master10.Board , Academics_Master10.YearOfPassing ,  Academics_Master10.Percentage10 ," +
            "Academics12.Institute , Academics12.Board , Academics12.YearOfPassing ,  Academics12.Percentage12 ," +
            "Academics_Master_Graduation.Institute , Academics_Master_Graduation.University , Academics_Master_Graduation.YearOfPassing ,  Academics_Master_Graduation.PercentageBE ," +
            "Project.Project_Name , Project.Project_Description , Project.Project_Platform ,  Project.Project_Duration " +

            "FROM Basic_Info_Master  Inner JOIN Academics_Master_CCEE  ON Basic_Info_Master.StudentId = Academics_Master_CCEE.StudentId" +
            " Inner JOIN Academics_Master10   ON Basic_Info_Master.StudentId = Academics_Master10.StudentId " +
            " Inner JOIN Academics12   ON Basic_Info_Master.StudentId = Academics12.StudentId " +
            " Inner JOIN Academics_Master_Graduation   ON Basic_Info_Master.StudentId = Academics_Master_Graduation.StudentId " +
            " Inner JOIN Project   ON Basic_Info_Master.StudentId = Project.StudentId " +

            " where Basic_Info_Master.StudentId='"+ Session["stdid"].ToString()+"' ";

        //cmdFetch.CommandText  = "SELECT StudentId,FullName FROM Basic_Info_Master where StudentId = 777";

             cn.Open();
            SqlDataReader da = cmdFetch.ExecuteReader();
            if (da.Read())
            {
            //--------------Personal Details------------           
            lblStudentId.Text      = da["StudentId"].ToString();
            lblFullname.Text       = da["FullName"].ToString();
            lblEmail.Text          = da["EmailId"].ToString();
            lblMobileno.Text       = da["MobileNo"].ToString();
            lblAddress.Text        = da["Address"].ToString();
            lblPINCODE.Text        = da["PinCode"].ToString();
            lblCity.Text           = da["City"].ToString();
            lblState.Text          = da["State"].ToString();
            lblCountry.Text        = da["Country"].ToString();

             //-------------------CCEE details------------------
            lblCCEEMarks.Text      = da["CCEEMarks"].ToString();
            lblCCEEpercentage.Text = da["Percentage"].ToString();

            //-------------------SSC details------------------
            lbl10thinstitute.Text  = da["SchoolName"].ToString();
            lbl10thBoard.Text      = da["Board"].ToString();
            lbl10thyear.Text       = da["YearOfPassing"].ToString();
            lbl10thper.Text        = da["Percentage10"].ToString();
            if (Convert.ToDecimal(lbl10thper.Text) >= 60)
            {
                lbl10thgrade.Text = "I";
            }
            else if (Convert.ToDecimal(lbl10thper.Text) <= 60  )
            {
                lbl10thgrade.Text = "II";
            }
            else if (Convert.ToDecimal(lbl10thper.Text) <= 55)
            {
                lbl10thgrade.Text = "III";
            }
            //Convert.ToInt32(lbl10thper.Text) >= 55
            //-------------------HSC details------------------
            lbl12thinstitute.Text  = da["Institute"].ToString();
            lbl12thBoard.Text      = da["Board"].ToString();
            lbl12thyear.Text       = da["YearOfPassing"].ToString();
            lbl12thper.Text          = da["Percentage12"].ToString();
            if (Convert.ToDecimal(lbl12thper.Text) >= 60)
            {
                lbl12thgrade.Text = "I";
            }
            else if (Convert.ToDecimal(lbl12thper.Text) <= 60)
            {
                lbl12thgrade.Text = "II";
            }
            else if (Convert.ToDecimal(lbl12thper.Text) <= 55)
            {
                lbl12thgrade.Text = "III";
            }

            //-------------------DEGREE details------------------
            lblBEinstitute.Text    = da["Institute"].ToString();
            lblBEuniversity.Text   = da["University"].ToString();
            lblBEyear.Text         = da["YearOfPassing"].ToString();
            lblBEper.Text          = da["PercentageBE"].ToString();
            //Response.Write(lblBEper.Text);
            //Console.WriteLine(lblBEper.Text);

            if (Convert.ToDecimal(lblBEper.Text) >= 60)
            {
                lblBEgrade.Text = "I";
            }
            else if (Convert.ToDecimal(lblBEper.Text) <= 60)
            {
                lblBEgrade.Text = "II";
            }
            else if (Convert.ToDecimal(lblBEper.Text) <= 55)
            {
                lblBEgrade.Text = "III";
            }


            //-----------Project------------------
            lblTitle.Text = da["Project_Name"].ToString();
            lblPlateform.Text = da["Project_Platform"].ToString();
            lblDescription.Text = da["Project_Description"].ToString();
            lblDuration.Text = da["Project_Duration"].ToString()+" Months";

            //--------------------cureent date-------------
            //lblDate.Text =DateTime.Now.ToString("yyyy-MM-dd");



        }

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=" + Session["stdid"].ToString() + ".pdf");
        //Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        this.Page.RenderControl(hw);
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        //Response.Write(pdfDoc);
        Response.End();
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("StudentHomePage.aspx");
    }



    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("StudentHomePage.aspx");


    }
}