﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {



        if (!IsPostBack)
        {
            try
            {
                string user = Session["stdid"].ToString();
                if (user == null)
                {
                    Response.Redirect("LoginPage.aspx");
                }
            }
            catch
            {
                Response.Redirect("LoginPage.aspx");
            }
            label.Text = Session["stdid"].ToString();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";
            DataTable dt = new DataTable();
            SqlDataReader dataReader = null;
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("select MobileNo,Email from Registration where StudentId = '" + Session["stdid"] + "'; select FullName,DOB,Address,Country,State,City,PinCode,Nationality,Gender from Basic_info_Master where StudentId = '" + Session["stdid"] + "'");
                cmd.Connection = cn;
                dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    txtmobile.Text = (dataReader["MobileNo"].ToString());
                    txtemail.Text = (dataReader["Email"].ToString());

                }
                dataReader.NextResult();

                while (dataReader.Read())
                {

                    txtfullname.Text = (dataReader["FullName"].ToString());
                    txtdob.Text = (dataReader["DOB"].ToString());
                    txtaddr.Text = (dataReader["Address"].ToString());
                    txtcountry.Text = (dataReader["Country"].ToString());
                    txtstate.Text = (dataReader["State"].ToString());
                    txtcity.Text=(dataReader["City"].ToString());
                    txtpin.Text = (dataReader["PinCode"].ToString());
                    txtnational.Text = (dataReader["Nationality"].ToString());
                    txtgender.Text = (dataReader["Gender"].ToString());
                }

            }
            catch
            {
                cn.Close();
            }
            finally {
                cn.Close();
            }

            DataTable dt1 = new DataTable();
            SqlDataReader dataReader1 = null;
            
                cn.Open();
            SqlCommand cmd1 = new SqlCommand("select SchoolName,Board,TotalMarks,YearOfPassing,Percentage10 from Academics_Master10 where StudentId ='" + Session["stdid"] + "';select Institute,Board,TotalMarks,YearOfPassing,Percentage12 from Academics12 where StudentId ='" + Session["stdid"] + "'");
                cmd1.Connection = cn;
                dataReader1 = cmd1.ExecuteReader();
            try
            {
                while (dataReader1.Read())
                {
                    Schoolname.Value = (dataReader1["SchoolName"].ToString());
                    Text212.Value = (dataReader1["Board"].ToString());
                    Text414.Value = (dataReader1["TotalMarks"].ToString());
                    Text515.Value = (dataReader1["YearOfPassing"].ToString());
                    Text616.Value = (dataReader1["Percentage10"].ToString());


                }

                dataReader1.NextResult();
                while (dataReader1.Read())
                {
                    Text11.Value = (dataReader1["Institute"].ToString());
                    Text22.Value = (dataReader1["Board"].ToString());
                    txt1.Text= (dataReader1["TotalMarks"].ToString());
                    yop12.Text= (dataReader1["YearOfPassing"].ToString());
                    per12.Text= (dataReader1["Percentage12"].ToString());
                }
            }
            catch
            {
                cn.Close();
            }
            finally
            {
                cn.Close();
            }


            //////////////////////////////////////////////////////////////////

            DataTable dt2 = new DataTable();
            SqlDataReader dataReader2 = null;

            cn.Open();
            SqlCommand cmd2 = new SqlCommand("select Institute,University,TotalMarks,YearOfPassing,PercentageBE from Academics_Master_Graduation where StudentId ='" + Session["stdid"] + "';select CCEEMarks,Percentage,WorkExperience from Academics_Master_CCEE where StudentId ='" + Session["stdid"] + "';select Project_Name,Project_Description,Project_Platform,Project_Duration from Project where StudentId='" + Session["stdid"] + "'");
            cmd2.Connection = cn;
            dataReader2 = cmd2.ExecuteReader();
            try
            {
                while (dataReader2.Read())
                {
                    Text111.Value = (dataReader2["Institute"].ToString());
                    Text222.Value = (dataReader2["University"].ToString());
                    TextBox4.Text = (dataReader2["TotalMarks"].ToString());
                    TextBox5.Text = (dataReader2["YearOfPassing"].ToString());
                    TextBox6.Text = (dataReader2["PercentageBE"].ToString());


                }

                dataReader2.NextResult();
                while (dataReader2.Read())
                {
                    Text111113.Value = (dataReader2["CCEEMarks"].ToString());
                    TextBox8.Text = (dataReader2["Percentage"].ToString());
                    TextBox7.Text = (dataReader2["WorkExperience"].ToString());
                    
                }
                dataReader2.NextResult();
                 while(dataReader2.Read())
                {
                    Text111111.Value = (dataReader2["Project_Name"].ToString());
                    Text22222.Value= (dataReader2["Project_Description"].ToString());
                    Text44444.Value= (dataReader2["Project_Platform"].ToString());
                    Text55555.Value= (dataReader2["Project_Duration"].ToString());
                }
            }
            catch
            {
                cn.Close();
            }
            finally
            {
                cn.Close();
            }


        }


        //////////////////////////////////////////////////////////


    



}

    protected void Button1_Click(object sender, EventArgs e)
    {
        lblstudid.Text = Session["stdid"].ToString();
      
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandType = CommandType.StoredProcedure;
        cmdInsert.CommandText = "AcademicsProcedure10";

        cmdInsert.Parameters.AddWithValue("@StudentId", lblstudid.Text);
        cmdInsert.Parameters.AddWithValue("@SchoolName", Request["schoolname"]);
        cmdInsert.Parameters.AddWithValue("@Board", Text212.Value);
        cmdInsert.Parameters.AddWithValue("@TotalMarks", Text414.Value);
        cmdInsert.Parameters.AddWithValue("@YearOfPassing", Text515.Value);
        cmdInsert.Parameters.AddWithValue("@Percentage10", Text616.Value);
        

        cn.Open();
        cmdInsert.ExecuteNonQuery();
        cn.Close();
    }
    protected void btn1submit_Click(object sender, EventArgs e)
    {

        
       

        //  lblstudid.Text = Session["stdid"].ToString();
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.CommandType = CommandType.StoredProcedure;
        cm.CommandText = "PersonalDetails";
        //cm.CommandType = CommandType.Text;
        //cm.CommandText = "insert into Basic_Info_Master values(@StudentId, @FullName, @EmailId , @MobileNo, @DOB , @Address, @Country, @State , @City,    @PinCode,    @Nationality ,    @Gender)";

        cm.Parameters.AddWithValue("@StudentId", Session["stdid"].ToString());     
        cm.Parameters.AddWithValue("@FullName", txtfullname.Text);
        cm.Parameters.AddWithValue("@EmailId", txtemail.Text);
        cm.Parameters.AddWithValue("@MobileNo", txtmobile.Text);
        cm.Parameters.AddWithValue("@DOB", txtdob.Text);
        cm.Parameters.AddWithValue("@Address", txtaddr.Text);
        cm.Parameters.AddWithValue("@Country", txtcountry.Text);
        cm.Parameters.AddWithValue("@State", txtstate.Text);
        cm.Parameters.AddWithValue("@City", txtcity.Text);
        cm.Parameters.AddWithValue("@Pincode", txtpin.Text);
        cm.Parameters.AddWithValue("@Nationality", txtnational.Text);
        cm.Parameters.AddWithValue("@Gender", txtgender.Text);

        cn.Open();
       
        cm.ExecuteNonQuery();
        cn.Close();

      



    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandType = CommandType.StoredProcedure;
        cmdInsert.CommandText = "AcademicsProcedure12";

        cmdInsert.Parameters.AddWithValue("@StudentId", Session["stdid"].ToString());
        cmdInsert.Parameters.AddWithValue("@Institute", Text11.Value);
        cmdInsert.Parameters.AddWithValue("@Board", Text22.Value);
        cmdInsert.Parameters.AddWithValue("@TotalMarks", txt1.Text);
        cmdInsert.Parameters.AddWithValue("@YearOfPassing", yop12.Text);
        cmdInsert.Parameters.AddWithValue("@Percentage12", per12.Text);

        cn.Open();
        cmdInsert.ExecuteNonQuery();
        cn.Close();
    }

    protected void Button10_Click(object sender, EventArgs e)
    {
        lblstudid.Text = Session["stdid"].ToString();
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandType = CommandType.StoredProcedure;
        cmdInsert.CommandText = "GraduationMaster";

        cmdInsert.Parameters.AddWithValue("@StudentId", lblstudid.Text);
        cmdInsert.Parameters.AddWithValue("@Institute", Text111.Value);
        cmdInsert.Parameters.AddWithValue("@University", Text222.Value);
        cmdInsert.Parameters.AddWithValue("@TotalMarks", TextBox4.Text);
        cmdInsert.Parameters.AddWithValue("@YearOfPassing",TextBox5.Text);
        cmdInsert.Parameters.AddWithValue("@PercentageBE", TextBox6.Text);

        cn.Open();
        cmdInsert.ExecuteNonQuery();
        cn.Close();
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandType = CommandType.StoredProcedure;
        cmdInsert.CommandText = "AcademicsProcedureccee";

        cmdInsert.Parameters.AddWithValue("@StudentId", Session["stdid"].ToString());
        cmdInsert.Parameters.AddWithValue("@CCEEMarks", Text111113.Value);
        cmdInsert.Parameters.AddWithValue("@Percentage", TextBox8.Text);
        cmdInsert.Parameters.AddWithValue("@WorkExperience", TextBox7.Text);

        

        cn.Open();
        cmdInsert.ExecuteNonQuery();
        cn.Close();

        string Student_Id1 = Session["stdid"].ToString();
        SqlConnection cn1 = new SqlConnection();
        cn1.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";
        SqlCommand cmdInsert1 = new SqlCommand();
        cmdInsert1.Connection = cn1;
        cmdInsert1.CommandType = CommandType.Text;
        for(int i=0;i<CheckBoxList1.Items.Count;i++)
        {
            if (CheckBoxList1.Items[i].Selected)
            {
                cn1.Open();
                cmdInsert1.CommandText = "Insert into Student_Preference_Table values('" + Student_Id1 + "','" + CheckBoxList1.Items[i].Value + "')";

                cmdInsert1.ExecuteNonQuery();
                cn1.Close();
                //cmdInsert.CommandText = "Insert into Student_Preference_Table(StudentId,preferenceId) values(@Student_Id1,@Id1)";
                //cmdInsert.Parameters.AddWithValue("@StudentId1", Student_Id1);
                //cmdInsert.Parameters.AddWithValue("@Id1", Id1);
            }
            //cmdInsert.CommandText = "Insert into Student_Preference_Table(StudentId,preferenceId) values(Student_Id,Id1)";
        }






    }

    protected void Button9_Click1(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("HomePage.aspx");
    }


    protected void Button7_Click(object sender, EventArgs e)
    {

        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandType = CommandType.StoredProcedure;
        cmdInsert.CommandText = "Project_Procedure";

        cmdInsert.Parameters.AddWithValue("@StudentId", Session["stdid"].ToString());
        cmdInsert.Parameters.AddWithValue("@Project_Name", Text111111.Value);
        cmdInsert.Parameters.AddWithValue("@Project_Description", Text55555.Value);
        cmdInsert.Parameters.AddWithValue("@Project_Platform", Text44444.Value);
        cmdInsert.Parameters.AddWithValue("@Project_Duration", Text22222.Value);




        cn.Open();
        cmdInsert.ExecuteNonQuery();
        cn.Close();

       



    }

  

    protected void Button12_Click(object sender, EventArgs e)
    {
        Response.Redirect("Resume.aspx");
    }

    protected void Button13_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewAlumni.aspx");
    }
}

