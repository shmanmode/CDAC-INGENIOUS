﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegistertpoPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void tporegisterbtn_Click(object sender, EventArgs e)
    {


        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandType = CommandType.StoredProcedure;
        cmdInsert.CommandText = "TpoRegisterProcedure";

        cmdInsert.Parameters.AddWithValue("@TpoUserId", Request["tpouserid"]);
        cmdInsert.Parameters.AddWithValue("@UserName", Request["username"]);
        cmdInsert.Parameters.AddWithValue("@TpoEmail", Request["tpoemail"]);
        cmdInsert.Parameters.AddWithValue("@Password", Request["password"]);
        

        
        cn.Open();
        cmdInsert.ExecuteNonQuery();
        cn.Close();
       
            //SMTP MAIL----------------------------------------------------------------------------------------------
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential("cdac.ingenious@gmail.com", "Password888");
            MailMessage msgobj = new MailMessage();
            msgobj.To.Add(Request["tpoemail"]);
            msgobj.From = new MailAddress("cdac.ingenious@gmail.com");
            msgobj.Subject = "CDAC-IGNENIOUS";
            msgobj.Body = "Hello \n UserId : " + Request["tpouserid"] + " \n" + Request["username"] + " You have registered successfully to CDAC-INGENIOUS ";
            client.Send(msgobj);


            Response.Redirect("logintpo.aspx");
    }
}