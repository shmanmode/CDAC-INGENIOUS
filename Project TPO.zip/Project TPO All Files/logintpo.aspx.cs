﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class logintpo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void studloginbtn_Click(object sender, EventArgs e)
    {

    }

    protected void tpologinbtn_Click(object sender, EventArgs e)
    {
        Session["userId"] = Request["Userid"];
        Session["password"] = Request["password"];

        string tpouserid = Request["UserId"];
        string password = Request["password"];
        if (CheckUser(tpouserid, password))
        {
            Session["userId"] = Request["Userid"];
            Response.Redirect("TPOHomePage.aspx");
        }
        else
        {
            Response.Redirect("logintpo.aspx");
        }


    }



    private bool CheckUser(string tpouserid, string password)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.CommandType = CommandType.Text;
        cm.CommandText = "select count(*) from TPORegister where TpoUserId=@tpouserid and Password=@password";
        cm.Parameters.AddWithValue("@tpouserid", tpouserid);
        cm.Parameters.AddWithValue("@password", password);
        cn.Open();
        int result = (int)cm.ExecuteScalar();
        cn.Close();
        if (result == 1)
            return true;
        else
            return false;
    }












    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        int intId = 100;

        string strPopup = "<script language='javascript' ID='script1'>"

        // Passing intId to popup window.
        + "window.open('TPOForgetPassword.aspx?data=" + HttpUtility.UrlEncode(intId.ToString())

        + "','new window', 'top=90, left=200, width=300, height=100, dependant=no, location=0, alwaysRaised=no, menubar=no, resizeable=no, scrollbars=n, toolbar=no, status=no, center=yes')"

        + "</script>";

        ScriptManager.RegisterStartupScript((Page)HttpContext.Current.Handler, typeof(Page), "Script1", strPopup, false);
    }
}