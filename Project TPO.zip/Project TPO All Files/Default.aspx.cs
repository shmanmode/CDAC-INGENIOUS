﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //MailMessage feedBack = new MailMessage();
        //feedBack.To.Add("rushali.pote@gmail.com");
        //feedBack.From = new MailAddress("rushali.pote@gmail.com");
        //feedBack.Subject = txtSubject.Text;
        //feedBack.Body = "Sender Name: " + txtName.Text + "<br><br>Sender Email: " + txtMail.Text + "<br><br>" + txtMessage.Text;
        //feedBack.IsBodyHtml = true;
        //SmtpClient smtp = new SmtpClient();
        //smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
        //smtp.Port = 587;
        //smtp.EnableSsl = true;
        //smtp.Credentials = new System.Net.NetworkCredential("rushali.pote@gmail.com",);
        ////Or your Smtp Email ID and Password
        //smtp.Send(feedBack);
        //Label1.Text = "Thanks for contacting us";
        try
        {
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential("cdac.ingenious@gmail.com", "Password888");
            MailMessage msgobj = new MailMessage();
            msgobj.To.Add("cdac.ingenious@gmail.com");
            msgobj.From = new MailAddress("cdac.ingenious@gmail.com");
            msgobj.Subject = txtMail.Text+" "+txtSubject.Text;
            msgobj.Body = "Got Mail from \n"+ txtName.Text+"\n" +txtMail+"\n "+txtMessage.Text;
            client.Send(msgobj);


            Response.Write("something Went Wrong");

           Label1.Text = "Thanks for contacting us";
        }
        catch (Exception ex)
        {
            Response.Write("something Went Wrong" + ex.Message);
        }
    }
}