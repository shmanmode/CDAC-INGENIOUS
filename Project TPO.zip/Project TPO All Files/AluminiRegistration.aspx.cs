﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AluminiRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void aluminiregisterbtn_Click(object sender, EventArgs e)
    {
      

        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandType = CommandType.StoredProcedure;
        cmdInsert.CommandText = "AlumniProcedure";

        cmdInsert.Parameters.AddWithValue("@Id", Aluminiid.Value);
        cmdInsert.Parameters.AddWithValue("@AlumniName", Alumininame.Value);
        cmdInsert.Parameters.AddWithValue("@AlumniMobileNo", Aluminimobileno.Value);
        cmdInsert.Parameters.AddWithValue("@AlumniCompany", Aluminicompany.Value);
        cmdInsert.Parameters.AddWithValue("@AlumniEmail", Aluminiemail.Value);
        cmdInsert.Parameters.AddWithValue("@Password", Aluminipass.Value);


        cn.Open();
        cmdInsert.ExecuteNonQuery();
        cn.Close();
        Session["name"] = Aluminiid.Value;
        Session["password"] = Aluminipass.Value;
        Response.Redirect("AluminiLogin.aspx");

    }
}