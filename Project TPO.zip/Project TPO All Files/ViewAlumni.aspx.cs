﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewAlumni : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

            SqlCommand command = new SqlCommand();
            command.Connection = conn;
            command.CommandType = CommandType.Text;
            command.CommandText = "Select AlumniName,AlumniMobileNo,AlumniCompany,AlumniEmail from Alumni_Details";

            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = command;

            DataSet ds = new DataSet();
            da.Fill(ds, "register");
            conn.Close();

            GridView1.DataSource = ds.Tables["register"];
            GridView1.DataBind();

        }
    }
}