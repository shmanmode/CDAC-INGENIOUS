﻿$(document).ready(function () {
    $(".tpoan").click(function () {
        $("#showme").show();
        $("#divsthatIwanttohide").hide();

    });

});