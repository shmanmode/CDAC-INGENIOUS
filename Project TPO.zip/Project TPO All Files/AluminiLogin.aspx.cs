﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AluminiLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



   
    protected void aluminiloginbtn_Click(object sender, EventArgs e)
    {
        int username = Convert.ToInt32( alid.Value);
        string password =alpass.Value;
        if (CheckUser(username, password))
        {
            Session["aluid"] = alid.Value;
            Session["password"] = alpass.Value;
            Response.Redirect("AluminiHomePage.aspx");
        }
        else
        {
            Response.Redirect("AluminiLogin.aspx");
        }

        
    }
    private bool CheckUser(int username, string password)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.CommandType = CommandType.Text;
        cm.CommandText = "select count(*) from Alumni_Details where Id=@AluId and Password=@password";
        cm.Parameters.AddWithValue("@AluId", username);
        cm.Parameters.AddWithValue("@password", password);
        cn.Open();
        int result = (int)cm.ExecuteScalar();
        cn.Close();
        if (result == 1)
            return true;
        else
            return false;
    }
}