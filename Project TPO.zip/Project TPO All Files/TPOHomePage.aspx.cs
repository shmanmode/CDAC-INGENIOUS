﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TPOHomePage : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
        if (!IsPostBack)
        {
            try
            {
                string user = Session["userId"].ToString();
                if (user == null)
                {
                    Response.Redirect("logintpo.aspx");
                }
            }
            catch
            {
                Response.Redirect("logintpo.aspx");
            }
        }
        }

    protected void btnStudentData_Click(object sender, EventArgs e)
    {
       
       // Response.Redirect("TPOHomePage.aspx");
    }

    protected void btnFilter_Click(object sender, EventArgs e)
    {

    }

    protected void btn1_Click(object sender, EventArgs e)
    {
       
    }

    protected void Button1_Click(object sender, EventArgs e)
    {


        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand command = new SqlCommand();
        command.Connection = conn;
        command.CommandType = CommandType.Text;
        command.CommandText = "Select StudentId,FirstName,MobileNo,Email from Registration";

        conn.Open();
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = command;

        DataSet ds = new DataSet();
        da.Fill(ds, "register");
        conn.Close();
       
        GridView2.DataSource = ds.Tables["register"];
        GridView2.DataBind();



    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("FilterFormPage.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("PlacedStudent.aspx");
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
       



    }

    

    protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand command = new SqlCommand();
        command.Connection = conn;
        command.CommandType = CommandType.Text;
        Label lblId = (Label)GridView2.Rows[e.RowIndex].FindControl("Label1");

        command.CommandText = "delete from Registration where StudentId ='"+lblId.Text+"'";

        conn.Open();
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = command;

        DataSet ds = new DataSet();
        da.Fill(ds, "register");
        conn.Close();

        GridView2.DataSource = ds.Tables["register"];
        GridView2.DataBind();
    }

    protected void Button9_Click1(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("HomePage.aspx");
    }

    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand command = new SqlCommand();
        command.Connection = conn;
        command.CommandType = CommandType.Text;
        command.CommandText = "Select StudentId,FirstName,MobileNo,Email from Registration";

        conn.Open();
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = command;

        DataSet ds = new DataSet();
        da.Fill(ds, "register");
        conn.Close();
        GridView2.PageIndex = e.NewPageIndex;
        GridView2.DataSource = ds.Tables["register"];
        GridView2.DataBind();
    }
}