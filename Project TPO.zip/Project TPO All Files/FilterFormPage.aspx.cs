﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FilterFormPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button4_Click(object sender, EventArgs e)
    {



        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";

        SqlCommand command = new SqlCommand();
        command.Connection = conn;
        command.CommandType = CommandType.Text;
        command.CommandText = "select r.StudentId,r.FirstName,r.MobileNo,r.Email from Registration r INNER JOIN Student_Preference_Table ch ON ch.StudentId = r.StudentId AND ch.preferenceId = '" + Convert.ToInt32(DropDownList1.SelectedValue) + "'INNER JOIN Academics_Master10 ssc ON ssc.StudentId=r.StudentId AND ssc.Percentage10 >= '" + TextBox1.Text + "' INNER JOIN Academics12 hsc ON hsc.StudentId=r.StudentId AND hsc.Percentage12 >='" + TextBox2.Text + "'INNER JOIN Academics_Master_Graduation d ON d.StudentId=r.StudentId AND d.PercentageBE >='" + TextBox3.Text + "'INNER JOIN Academics_Master_CCEE c ON c.StudentId=r.StudentId AND c.Percentage >='" + TextBox4.Text + "'";

        conn.Open();
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = command;

        DataSet ds = new DataSet();
        da.Fill(ds, "register");
        conn.Close();
        GridView1.DataSource = ds.Tables["register"];
        GridView1.DataBind();

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        try
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;AttachDbFilename=C:\Users\dell\Project.mdf;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select r.Email,r.FirstName from Registration r INNER JOIN Student_Preference_Table ch ON ch.StudentId = r.StudentId AND ch.preferenceId = '" + Convert.ToInt32(DropDownList1.SelectedValue) + "'INNER JOIN Academics_Master10 ssc ON ssc.StudentId=r.StudentId AND ssc.Percentage10 >= '" + TextBox1.Text + "' INNER JOIN Academics12 hsc ON hsc.StudentId=r.StudentId AND hsc.Percentage12 >='" + TextBox2.Text + "'INNER JOIN Academics_Master_Graduation d ON d.StudentId=r.StudentId AND d.PercentageBE >='" + TextBox3.Text + "'INNER JOIN Academics_Master_CCEE c ON c.StudentId=r.StudentId AND c.Percentage >='" + TextBox4.Text + "'";
            //string email;
           
            cn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                //email = dr[0].ToString();
                string email= dr["Email"].ToString();
                string Name = dr["FirstName"].ToString();

                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                client.EnableSsl = true;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential("cdac.ingenious@gmail.com", "Password888");
                MailMessage msgobj = new MailMessage();
                msgobj.To.Add(email);
                msgobj.From = new MailAddress("cdac.ingenious@gmail.com");
                msgobj.Subject = "Interview Schedule";
                msgobj.Body = " Hello " +Name+"\n\n    Your resume has been shortlisted for Reliance Jio,Your Interview is scheduled on " + DateTime.Today.AddDays(5).ToString("dd-MM-yyyy") + " at 10:00 AM Sharp \n at Mahape,Navi-Mumbai. Your package is 7 LPA" + " \n\n\n HR ADMIN,\n CDAC";
                client.Send(msgobj);
                //Response.Write("Mail send successfully");
                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert('message has been sent successfully');", true);
            }
        }
        catch (Exception ex)
        {
            Response.Write("Could not send Email" + ex.Message);
        }
        Response.Redirect("TPOHomePage.aspx");          

    }
}